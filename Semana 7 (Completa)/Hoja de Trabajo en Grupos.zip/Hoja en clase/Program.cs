﻿using System;
using System.Numerics;

class Program
{
    static void Main()
    {
        Console.WriteLine("Hoja de Trabajo en Grupos");
        Console.WriteLine("José Sosa - Sergio Mayen - Jorge Muñoz\n\n");

        Console.WriteLine("Ejercicio 1 ");

        int n = 1;
        int n2 = 1;

        Console.WriteLine("Ingresar un valor positivo ");
        n2 = Convert.ToInt32(Console.ReadLine());

        while(n>=1 && n<=n2)
        {
            Console.WriteLine(n);
            n++;
        }

        Console.WriteLine("Fin del programa \n");

        Console.WriteLine("\nEjercicio 2 ");

        int x = 0;
        int x2 = 0;
        int suma = 0;
        int prom = 0;
        char final = 'n';

        while(final =='n')
        {
            Console.WriteLine("Ingresar un valor");
            x = Convert.ToInt32(Console.ReadLine());

            x2++;
            suma = x+suma;
            prom = suma/x2;

            Console.WriteLine("Suma = " +  suma);
            Console.WriteLine("Promedio = " + prom);

            Console.WriteLine("Desea finalizar? n = no s = si");
            final = Convert.ToChar(Console.ReadLine());
        }

        Console.WriteLine("Fin del programa \n");

        Console.WriteLine("\nEjercicio 3 ");

        int valor = 0;
        int cant = 0;
        int sum= 0;
        int multi = 0;
        char fin = 'a';

        while(fin == 'a')
        {
            Console.WriteLine("Ingresar el valor del producto");
            valor = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese la cantidad");
            cant= Convert.ToInt32(Console.ReadLine());

            multi = valor * cant;
            sum = sum + multi;

            Console.WriteLine("Total parcial a pagar: " + multi);
            Console.WriteLine("TOTAL: " + sum);

            Console.WriteLine("¿Desea continuar? a = si, b = no");
            fin = Convert.ToChar(Console.ReadLine());
        }

        Console.WriteLine("Compra finalizada.");

    }
}
