﻿using System;
using System.Diagnostics.CodeAnalysis;

class Program
{
    static void Main()
    {
        Console.WriteLine("Trabajo Individual Semana 7 - Jorge Muñoz - 1177523\n");
        Console.WriteLine("\nPrimer Inciso\n");
        int total = 0;
        int count = 0;

        Console.WriteLine("Ingresar 10 números mayores que cero:");
        while (count < 10)
        {
            int n = Convert.ToInt32(Console.ReadLine());

            if (n > 0)
            {
                total = total + n;
                count++;
            }
            else
            {
                Console.WriteLine("\n---El número que se ingreso debe ser mayor a 0---\n");
                Console.WriteLine("Ingresar los números faltantes mayores a 0:");
            }
        }
        double prom = (double) total / count;
        Console.WriteLine("\nEl promedio final es: " + prom);
        Console.ReadKey();

        Console.Clear();
        Console.WriteLine("Trabajo Individual Semana 7 - Jorge Muñoz - 1177523\n");
        Console.WriteLine("Segundo Inciso\n");

        int y = 2;
        while (y < 30)
        {
            bool x = true;

            for (int i = 2; i <= Math.Sqrt(y); i++)
            {
                if (y % i == 0)
                {
                    x = false;
                    break;
                }
            }
            if (x)
            {
                Console.Write(y + " ");
            }
            y++;
        }
        Console.ReadKey();
    }
}