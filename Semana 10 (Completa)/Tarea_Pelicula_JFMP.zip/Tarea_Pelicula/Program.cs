﻿using System;

namespace T_PELICULA
{
    public class Pelicula
    {
        private string nombre, genero, valoracion;
        private double duracion, calificacion;
        private int anio;

        public int Anio { get { return anio; } }
        public string Nombre { get { return nombre; } }
        public string Genero { get { return genero; } }
        public string Valoracion { get { return valoracion; } }
        public double Duracion { get { return duracion; } }
        public double Calificacion { get { return calificacion; } }

        public Pelicula(string laValoracion, string elGenero)
        {
            nombre = "";
            genero = elGenero;
            valoracion = laValoracion;
            calificacion = 0;
            duracion = 0;
            anio = 0;
        }
      
        public string MostrarInformacion()
        {
            return $"El nombre de la pelicula es: - {nombre} -\nLa duración de la pelicula es de: {duracion} minutos.\nEl género es: {genero}\nEl año es: {anio}\nLa calificación es: {calificacion}\nLa valoración es: {valoracion}";
        }

        public bool esPeliculaEpica()
        {
            if (duracion >= 180)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string laCalificacion()
        {
            if (calificacion >= 0 && calificacion <= 2)
            {
                valoracion = "Muy mala";
                return valoracion;
            }
            else if (calificacion > 2 && calificacion <= 5) 
            {
                valoracion = "Mala";
                return valoracion;
            }
            else if (calificacion > 5 && calificacion <= 7)
            {
                valoracion = "Regular";
                return valoracion;
            }
            else if (calificacion > 7 && calificacion <= 8)
            {
                valoracion = "Buena";
                return valoracion;
            }
            else if (calificacion > 8 && calificacion <= 10)
            {
                valoracion = "Excelente";
                return valoracion;
            }
            else
            {
                valoracion = "";
                return valoracion;
            }
        }

        public bool esSimilar(Pelicula otraPelicula)
        {
            if (this.genero == otraPelicula.genero && this.valoracion == otraPelicula.valoracion)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void Main()
        {
            Console.WriteLine("| Tarea - Pelicula || Jorge Muñoz - 1177523 |\n");

            Pelicula pelicula1 = new Pelicula("Excelente", "Drama");
            pelicula1.nombre = "Ghandi";
            pelicula1.duracion = 191;
            pelicula1.anio = 1982;
            pelicula1.calificacion = 8.1;
            Console.WriteLine(pelicula1.MostrarInformacion());
            Console.Write("¿Es pelicula epica?: " + pelicula1.esPeliculaEpica());
            Console.WriteLine("\n");

            Pelicula pelicula2 = new Pelicula("Buena", "Acción");
            pelicula2.nombre = "Thor";
            pelicula2.duracion = 115;
            pelicula2.anio = 2011;
            pelicula2.calificacion = 7;
            Console.WriteLine(pelicula2.MostrarInformacion());
            Console.Write("¿Es pelicula epica?: " + pelicula2.esPeliculaEpica());
            Console.WriteLine("\n");

            bool similares = pelicula1.esSimilar(pelicula2);

            Console.WriteLine($"¿Las películas son similares?: {similares}");

            Console.ReadKey();
        }
    }
}