﻿using System;

public class Libro
{
    private int codigo, cantidad, pagina, contador, lectura;
    private string nombre, estado, mensaje;
    private double porcentaje;

    public int Codigo { get { return codigo; } }
    public int Cantidad { get { return cantidad; } }
    public int Pagina { get { return pagina; } }
    public int Contador { get { return contador; } }
    public int Lectura { get { return lectura; } }
    public string Nombre { get { return nombre;} }
    public string Estado { get { return estado; } }
    public string Mensaje { get { return mensaje; } }
    public double Porcentaje { get { return porcentaje; } }

    public Libro(int codigo, int cantidad, int pagina, int contador, int lectura, string nombre, string estado, string mensaje, double porcentaje)
    {
        this.codigo = codigo;
        this.cantidad = cantidad;
        this.pagina = pagina;
        this.contador = contador;
        this.lectura = lectura;
        this.nombre = nombre;
        this.estado = estado;
        this.mensaje = mensaje;
        this.porcentaje = porcentaje;
    }

    public string leerParametros(int cant)
    {
        lectura = cant;

        if (lectura > cantidad)
        {
            mensaje = "No se pueden leer más páginas.";
        }
        else
        {
            contador = cant;
        }
        return mensaje;
    }

    public double obtenerPorcentaje()
    {
        porcentaje = (contador * 100.00) / cantidad;
        return porcentaje;
    }

    public int paginaActual()
    {
        return lectura;
    }

    public string mostrarLibro()
    {
        return $"El codigo es: {codigo}\nEl nombre es: {nombre}\nLa cantidad de página es: {cantidad}\nEl porcentaje de lectura es: {porcentaje}\nLa cantidad de páginas leidas es: {lectura}";
    }

    public string estadoLibro()
    {
        if (contador == cantidad)
        {
            estado = "Leido";
        }
        else if (contador < cantidad)
        {
            estado = "En proceso";
        }
        else
        {
            estado = "No leido";
        }
        return estado;
    }

    public static void Main()
    {
        Libro libro1 = new Libro(1, 101, 100, 0, 0, "Primer Libro", "", "", 0.0);
        libro1.leerParametros(10);
        Console.WriteLine(libro1.mostrarLibro());
        Console.ReadKey();
    }
}